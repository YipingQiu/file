#!/bin/bash
CWD=$(cd "$(dirname $0)";pwd)
"$CWD"/livecms stop
"$CWD"/livecms uninstall 