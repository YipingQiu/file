#!/bin/bash
CWD=$(cd "$(dirname $0)";pwd)
"$CWD"/livesms stop
"$CWD"/livesms uninstall